1 This code is for the paper: [1] Z. Liu, W. Zou, L. Li, L. Shen and O. Le Meur, "Co-Saliency Detection Based on Hierarchical Segmentation," IEEE Signal Process. Lett., vol. 21, no. 1, pp. 88-92, Jan. 2014. It can only be used for non-comercial purpose. If you use this code, please cite the paper [1].

2 This code needs [2] P. Arbelaez, M. Maire, C. Fowlkes, J. Malik, "Contour detection and hierarchical image segmentation," IEEE Transactions on Pattern Analysis and Machine Intelligence, vol. 33, no. 5, pp. 898-916, May 2011. The source code for [2] is included in the "lib" folder and you can also downloade at http://www.eecs.berkeley.edu/Research/Projects/CS/vision/grouping/resources.html

3 We have tested this code under ubuntu 12.04. Run Demo.m in MATLAB and you will see an example.