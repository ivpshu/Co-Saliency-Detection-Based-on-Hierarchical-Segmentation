addpath lib;
clear all;close all;clc;

str_read = 'data/iCoseg/image/'; para.Suffix = '.jpg'; 
str_save = 'data/iCoseg/results/';
ucm_save = 'data/iCoseg/UCM/';

temp_dir_list = dir(str_read);
j = 0;
for i = 1 : length(temp_dir_list)
    if temp_dir_list(i).isdir == 1 && strcmp(temp_dir_list(i).name, '.') == 0 &&strcmp(temp_dir_list(i).name, '..') == 0 
        j = j + 1;
        dir_list(j) = temp_dir_list(i);
    end
end


%% Parameters
para.str_read=str_read;
para.str_save=str_save;
para.ucm_save=ucm_save;
para.numberOfDirs = size(dir_list,2);
para.numberOfFiles = zeros(para.numberOfDirs, 1);
para.dir_list=dir_list;

para.qn = 16;        
para.alph = 0.95; 

%% UCM
% matlabpool 4;
im2UCM(str_read, ucm_save, para)

%% CoSaliency
CoSal(para);





